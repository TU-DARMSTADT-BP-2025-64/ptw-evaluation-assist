import{c as a}from"../chunks/a2mPvBUy.js";export{a as start};
