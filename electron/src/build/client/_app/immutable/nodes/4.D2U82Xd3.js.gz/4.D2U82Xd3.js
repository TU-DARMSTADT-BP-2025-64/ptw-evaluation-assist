import{b as e,a as n}from"../chunks/CccQXOJz.js";export{e as component,n as universal};
